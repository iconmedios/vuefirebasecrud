<template>
    <div>
        <h1>Acerca</h1>
        <i>{{userStore.userData?.email}}</i>
        <p> Otra tienda: {{clienteStore.clienteData}}</p>
    </div>
</template>

<script setup>
import {useUserStore} from '../stores/user'
import {useClienteStore} from '../stores/cliente'
const userStore = useUserStore()
const clienteStore = useClienteStore()
</script>