import {defineStore} from 'pinia';
// clientes iconmedios firebase jean@

export const useClienteStore = defineStore( 'clienteStore',{ 

    state: ()=> ({
        // conectar base de datos
        datosCientes: []
        }),
        // obtener los datos
        actions:{
        async getClientes(){
            try {

            } catch (error){
                console.log(error);
            } finally {
        // para manejar un preload

            }
        }}

 
})//userClienteStore

